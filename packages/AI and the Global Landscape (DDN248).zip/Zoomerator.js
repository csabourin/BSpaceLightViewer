﻿function getCenterPosition(rect, scale, iframeWidth, iframeHeight, padding) {
  const centerX = (iframeWidth - (rect.width * scale) - (padding * 2)) / 2;
  const centerY = (iframeHeight - (rect.height * scale) - (padding * 2)) / 2;

  return { x: centerX, y: centerY };
}

function getCorrectScrollY() {
  let currentWindow = window;
  let scrollY = 0;

  while (currentWindow !== window.top) {
      scrollY += currentWindow.scrollY;
      currentWindow = currentWindow.parent;
  }

  return scrollY;
}

function getIframeDimensions() {
	const isInIframe = window !== window.top;
	let iframeWidth, iframeHeight;

	if (isInIframe) {
		iframeWidth = window.innerWidth;
		iframeHeight = window.innerHeight;
	} else {
		iframeWidth = window.innerWidth;
		iframeHeight = window.innerHeight;
	}

	return { iframeWidth, iframeHeight };
}

function zoomImage(container) {
    const img = container.querySelector("img");
    const { iframeWidth, iframeHeight } = getIframeDimensions();
  
    if (document.getElementById("overlay")) {
      const overlay = document.getElementById("overlay");
      const clonedImg = overlay.querySelector("img");
      const rect = img.getBoundingClientRect();
  
      clonedImg.style.transform = "scale(1)";
      clonedImg.style.top = `${rect.top + getCorrectScrollY()}px`;
      clonedImg.style.left = `${rect.left + window.scrollX}px`;
  
      overlay.classList.remove("show");
  
      setTimeout(() => {
        overlay.remove();
      }, 500);
    } else {
      const overlay = document.createElement("div");
      overlay.id = "overlay";
      overlay.classList.add("overlay");
      overlay.onclick = () => zoomImage(container);
  
      const clonedImg = img.cloneNode(true);
      const rect = img.getBoundingClientRect();
      clonedImg.style.top = `${rect.top + getCorrectScrollY()}px`;
      clonedImg.style.left = `${rect.left + window.scrollX}px`;
      clonedImg.style.width = `${img.offsetWidth}px`;
      clonedImg.style.height = `${img.offsetHeight}px`;
      overlay.appendChild(clonedImg);
  
      const padding = 10;
      const scaleX = (iframeWidth - (padding * 2)) / img.offsetWidth;
      const scaleY = (iframeHeight - (padding * 2)) / img.offsetHeight;
      const scale = Math.min(scaleX, scaleY);
      const { x: centerX, y: centerY } = getCenterPosition(rect, scale, iframeWidth, iframeHeight, padding);
  
      document.body.appendChild(overlay);
  
      setTimeout(() => {
        clonedImg.style.transform = `scale(${scale})`;
        clonedImg.style.top = `calc(${rect.top + getCorrectScrollY()}px + ${centerY - rect.top + (img.offsetHeight * (scale - 1)) / 2}px + ${padding}px)`;
        clonedImg.style.left = `calc(${rect.left + window.scrollX}px + ${centerX - rect.left + (img.offsetWidth * (scale - 1)) / 2}px + ${padding}px)`;
        
        overlay.classList.add("show");
      }, 10);
    }
  }
  
